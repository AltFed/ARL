#include "basic.h"
#include "prefork_io.h"

#define	MAXN	16384		/* max # bytes client can request */

void web_child(int sockfd)
{
  int	ntowrite,n;
  ssize_t	nread;
  char	line[MAXLINE], result[MAXN];

  	

  for ( ; ; ) {
    if ( (nread = readline(sockfd, line, MAXLINE)) == 0)
      return;		/* connection closed by other end */

    /* line from client specifies #bytes to write back */
    ntowrite = atol(line);
    if ((ntowrite <= 0) || (ntowrite > MAXN)) {
      fprintf(stderr, "client request for %d bytes", ntowrite);
      exit(1);
    }
    for(n=0;n<ntowrite-1;n++)
       result[n]='x';
    result[ntowrite-1]=0x0a;	

    n=writen(sockfd, result, ntowrite);
  }
}
