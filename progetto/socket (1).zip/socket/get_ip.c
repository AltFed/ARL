/* get_ip.c - code for hostname-to-IP address mapping 
   Ultima revisione: 14 gennaio 2008 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>

#define IP4_ADDRESSLEN	16

int main(int argc, char *argv[])
{
  char			*server_name, **server_IP;
  struct hostent 	*server_info;
  struct in_addr	in;
  int 			i, num_alias, num_addr;
  
  if (argc < 2) {
    fprintf(stderr, "Usage: get_ip hostname\n");
    exit(1);
  }  

  server_name = argv[1];
  server_info = gethostbyname(server_name);
  if (server_info == NULL) { 
    herror("gethostbyname");
    exit(1);
  }
  
  strcpy(server_name, server_info->h_name);  
  printf("Official name: %s\n", server_name);  

  /* How many aliases */ 
  num_alias = 0;
  while (server_info->h_aliases[num_alias] != NULL) 
    num_alias++;
  if (num_alias > 0) {     
    printf("Alias%s:", num_alias==1?"":"es");
    for (i=0; i<num_alias; i++) printf(" %s", server_info->h_aliases[i]);  
    printf("\n");  
  }
  else printf("No alias\n");
  
  /* How many addresses */ 
  num_addr = 0;
  while (server_info->h_addr_list[num_addr] != NULL) 
    num_addr++;    
  server_IP = (char **)calloc(num_addr, sizeof(char *));
  for (i=0; i<num_addr; i++) server_IP[i] = (char *)malloc(IP4_ADDRESSLEN);

  for (i=0; i<num_addr; i++) {
    memcpy(&in, server_info->h_addr_list[i], sizeof(in));
    strcpy(server_IP[i], (char *)inet_ntoa(in));
  }
  
  printf("Number of corresponding address%s: %d\n", num_addr==1?"":"es", num_addr);
  for (i=0; i<num_addr; i++) printf("Address %2d: %s\n", i+1, server_IP[i]);
  printf("\n");
  
  for (i=0; i<num_addr; i++) free(server_IP[i]);
  free(server_IP);
  
  return 0;
}
